# AtlasLib

## Please do not ask about WW, I'm working on it!!

A library used for Waffle's mods.

I'm not documenting this, either look at WW when it updates or the code.